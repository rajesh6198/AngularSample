import { FilesizePipe } from './filesize.pipe';

describe('FilesizePipe', () => {
  it('create an instance', () => {
    const pipe = new FilesizePipe();
    expect(pipe).toBeTruthy();
  });
});
