
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {
  constructor(private el: ElementRef) {
  }

    // this.ChangeBgColor('red');
   
   @HostListener('mouseover') onMouseOver() {
alert("dadaswdasd");
 
   }
     

  }


