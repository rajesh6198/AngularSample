import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppleService {

  constructor(  private http: HttpClient ) { }
  addCalulate(a,b):number{
return a+b;
  }
  getTodosData(){
    return this.http.get("https://jsonplaceholder.typicode.com/todos/1");
  }
}
