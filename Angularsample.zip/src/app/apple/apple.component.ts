import { Component, OnInit } from '@angular/core';
import { AppleService } from './apple.service';

@Component({
  selector: 'app-apple',
  templateUrl: './apple.component.html',
  styleUrls: ['./apple.component.css']
})
export class AppleComponent implements OnInit {
  name: string;
  userName: string;
  password: string;
  isEnable: boolean;
  usersList: any;
  getUserNames:any;
  value:string;
  addition:number;
  todosData:any;
  constructor(private appleService : AppleService) {

  }
  ngOnInit(): void {
    this.appleService.getTodosData().subscribe(data=>{
      this.todosData=data;
    });
  }
  onSave(): void {
    this.isEnable = true;
    this.getUserNames={userName:this.userName,password:this.password};
    this.usersList = [{ userName: "kamal", Id: 143434 },
    { userName: "kamal1", Id: 234 },
    { userName: "kamal2", Id: 343 },
    { userName: "kamal3", Id: 443 },
    { userName: "kamal4", Id: 5434 },
    ]
    
   // this.usersList=this.usersList.filter(user=> user.userName=="kamal2");
   this.addition= this.appleService.addCalulate(1,3);

  }
 
  
  getOutPut(value){
    this.value=value;
  }
}
